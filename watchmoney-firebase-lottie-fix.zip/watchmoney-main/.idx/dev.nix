# Firebase Studio / IDX environment for WatchMoney
# This pins the Android SDK components used by Gradle so the build does not try
# to install SDK packages into /nix/store, which is read-only.
{ pkgs, ... }:
let
  androidSdk = pkgs.android-sdk.compose {
    buildToolsVersions = [ "35.0.0" ];
    platformVersions = [ "35" ];
  };
in {
  channel = "stable-24.05";

  packages = [
    pkgs.jdk
    androidSdk
  ];

  env = {
    ANDROID_HOME = "${androidSdk}/libexec/android-sdk";
    ANDROID_SDK_ROOT = "${androidSdk}/libexec/android-sdk";
    JAVA_HOME = "${pkgs.jdk}";
  };

  idx = {
    extensions = [];
    previews = {
      enable = true;
      previews = {};
    };
    workspace = {
      onCreate = {};
      onStart = {};
    };
  };
}
