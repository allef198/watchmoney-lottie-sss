package com.allef198.watchmoney.composables

enum class AppScreen {
    Home,
    Wallet,
    History,
    Notifications,
    DailyBonus
}