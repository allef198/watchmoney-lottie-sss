package com.allef198.watchmoney

import android.util.Log
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

data class UserProfile(
    val uid: String = "",
    val email: String = "",
    val points: Long = 0,
    val history: List<String> = emptyList(),
    val blocked: Boolean = false,
    val dailyBonusLastClaimDate: String? = null,
    val dailyBonusStreakDay: Int? = null,
    val dailyBonusTotalEarned: Long? = null,
    val totalAdsWatched: Long = 0,
    val chestProgress: Int = 0,
    val xp: Long = 0
)

data class AppConfig(
    val withdrawEnabled: Boolean = true,
    val pointsPerReal: Long = 10000,
    val minWithdrawAmount: Double = 1.0,
    val maintenanceMode: Boolean = false,
    val globalMessage: String = ""
)

data class GlobalNotification(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val createdAt: Timestamp? = null,
    val createdBy: String = "",
    val active: Boolean = true
)

data class WithdrawalRequest(
    val id: String = "",
    val uid: String = "",
    val email: String = "",
    val fullName: String = "",
    val pixKey: String = "",
    val amountRequested: Double = 0.0,
    val pointsRequired: Long = 0,
    val status: String = "",
    val createdAt: Timestamp? = null,
    val pointsRefunded: Boolean? = false,
    val refundedAt: Timestamp? = null,
    val notificationSentForStatus: Map<String, Boolean> = emptyMap()
)

class UserRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val coroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loadingJob: Job? = null
    private var requestsListener: ListenerRegistration? = null
    private var notificationsListener: ListenerRegistration? = null
    private var globalNotificationsListener: ListenerRegistration? = null
    private var appConfigListener: ListenerRegistration? = null

    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile

    private val _appConfig = MutableStateFlow(AppConfig())
    val appConfig: StateFlow<AppConfig> = _appConfig

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _withdrawalMessage = MutableStateFlow<String?>(null)
    val withdrawalMessage: StateFlow<String?> = _withdrawalMessage

    private val _withdrawalRequests = MutableStateFlow<List<WithdrawalRequest>>(emptyList())
    val withdrawalRequests: StateFlow<List<WithdrawalRequest>> = _withdrawalRequests

    private val _isLoadingRequests = MutableStateFlow(false)
    val isLoadingRequests: StateFlow<Boolean> = _isLoadingRequests

    private val _requestsError = MutableStateFlow<String?>(null)
    val requestsError: StateFlow<String?> = _requestsError

    private val _notifications = MutableStateFlow<List<Notification>>(emptyList())
    val notifications: StateFlow<List<Notification>> = _notifications

    private val _isLoadingNotifications = MutableStateFlow(false)
    val isLoadingNotifications: StateFlow<Boolean> = _isLoadingNotifications

    private val _notificationsError = MutableStateFlow<String?>(null)
    val notificationsError: StateFlow<String?> = _notificationsError

    private val _globalNotifications = MutableStateFlow<List<GlobalNotification>>(emptyList())
    val globalNotifications: StateFlow<List<GlobalNotification>> = _globalNotifications

    private val _isLoadingGlobalNotifications = MutableStateFlow(false)
    val isLoadingGlobalNotifications: StateFlow<Boolean> = _isLoadingGlobalNotifications

    private val _globalNotificationsError = MutableStateFlow<String?>(null)
    val globalNotificationsError: StateFlow<String?> = _globalNotificationsError

    init {
        loadAppConfig()
        loadGlobalNotifications()
    }

    fun onCleared() {
        coroutineScope.cancel()
        requestsListener?.remove()
        notificationsListener?.remove()
        globalNotificationsListener?.remove()
        appConfigListener?.remove()
    }

    private fun loadAppConfig() {
        appConfigListener = firestore.collection("appConfig").document("settings")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    _appConfig.value = AppConfig()
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val config = snapshot.toObject(AppConfig::class.java)
                    if (config != null) {
                        _appConfig.value = config
                    }
                } else {
                    _appConfig.value = AppConfig()
                }
            }
    }

    fun loadUserProfile() {
        loadingJob?.cancel()

        loadingJob = coroutineScope.launch {
            _isLoading.value = true
            _error.value = null

            val user = auth.currentUser
            if (user == null) {
                Log.d("Firestore", "Auth user null")
                _userProfile.value = null
                _isLoading.value = false
                return@launch
            }

            Log.d("Firestore", "Auth user found: ${user.uid}")

            val timeoutJob = launch {
                delay(10000)
                if (_isLoading.value) {
                    Log.e("Firestore", "Loading timeout")
                    _error.value = "Demorou muito para carregar. Verifique sua internet e tente novamente."
                    _isLoading.value = false
                }
            }

            fetchFirestoreDocument(user, timeoutJob)
        }
    }

    private fun fetchFirestoreDocument(user: FirebaseUser, timeoutJob: Job) {
        Log.d("Firestore", "Loading user document")
        firestore.collection("users").document(user.uid).get()
            .addOnSuccessListener { document ->
                if (!_isLoading.value) return@addOnSuccessListener
                timeoutJob.cancel()

                if (document.exists()) {
                    Log.d("Firestore", "User document found")
                    _userProfile.value = document.toObject(UserProfile::class.java)
                    _isLoading.value = false
                    checkDailyBonus()
                } else {
                    Log.d("Firestore", "User document not found, creating")
                    createNewUserDocument(user)
                }
            }
            .addOnFailureListener { e ->
                if (!_isLoading.value) return@addOnFailureListener
                timeoutJob.cancel()
                Log.e("Firestore", "Firestore get failed", e)
                _error.value = "Erro ao carregar seus dados. Tente novamente."
                _isLoading.value = false
            }
    }

    private fun createNewUserDocument(user: FirebaseUser) {
        val newUser = UserProfile(uid = user.uid, email = user.email ?: "", blocked = false)
        val userMap = mapOf(
            "uid" to user.uid,
            "email" to (user.email ?: ""),
            "points" to 0L,
            "history" to emptyList<String>(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
            "blocked" to false,
            "dailyBonusLastClaimDate" to "",
            "dailyBonusStreakDay" to 0,
            "dailyBonusTotalEarned" to 0L,
            "totalAdsWatched" to 0L,
            "chestProgress" to 0,
            "xp" to 0L
        )

        firestore.collection("users").document(user.uid).set(userMap)
            .addOnSuccessListener {
                if (!_isLoading.value) return@addOnSuccessListener
                Log.d("Firestore", "User document created")
                _userProfile.value = newUser
                _isLoading.value = false
                checkDailyBonus()
            }
            .addOnFailureListener { e ->
                if (!_isLoading.value) return@addOnFailureListener
                Log.e("Firestore", "Firestore set failed", e)
                _error.value = "Erro ao criar seus dados. Tente novamente."
                _isLoading.value = false
            }
    }

    suspend fun onAdWatched(): Long {
        val user = auth.currentUser ?: return 0L
        val docRef = firestore.collection("users").document(user.uid)
        var pointsGained = 0L

        try {
            val (pointsToAdd, historyMessage) = firestore.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                val currentTotalAdsWatched = snapshot.getLong("totalAdsWatched") ?: 0
                val currentChestProgress = snapshot.getLong("chestProgress")?.toInt() ?: 0

                val newTotalAdsWatched = currentTotalAdsWatched + 1
                var newChestProgress = currentChestProgress + 1

                var pointsToAdd = 0L
                var historyMessage = ""

                when (newChestProgress) {
                    5 -> {
                        pointsToAdd = 25
                        historyMessage = "Recompensa da Barra do Baú: +25 pontos"
                    }
                    10 -> {
                        pointsToAdd = 25
                        historyMessage = "Recompensa da Barra do Baú: +25 pontos"
                    }
                    15 -> {
                        pointsToAdd = 50
                        historyMessage = "Super recompensa da Barra do Baú: +50 pontos"
                    }
                    20 -> {
                        pointsToAdd = 100
                        historyMessage = "Baú aberto: +100 pontos"
                        newChestProgress = 0
                    }
                }
                pointsGained = pointsToAdd

                val updates = mutableMapOf<String, Any>(
                    "totalAdsWatched" to newTotalAdsWatched,
                    "chestProgress" to newChestProgress,
                    "updatedAt" to FieldValue.serverTimestamp()
                )

                if (pointsToAdd > 0) {
                    val currentPoints = snapshot.getLong("points") ?: 0
                    val newPoints = currentPoints + pointsToAdd
                    updates["points"] = newPoints

                    val currentHistory = (snapshot.get("history") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    val newHistory = (listOf(historyMessage) + currentHistory).take(100)
                    updates["history"] = newHistory
                }

                transaction.update(docRef, updates)

                Pair(pointsToAdd, historyMessage)
            }.await()

            if (pointsToAdd > 0) {
                val notificationTitle = when (pointsToAdd) {
                    100L -> "🎁 Baú Aberto!"
                    50L -> "🔥 Super Recompensa!"
                    else -> "✅ Recompensa Liberada!"
                }
                val notificationMessage = "Você ganhou +$pointsToAdd pontos."
                createNotification(user.uid, notificationTitle, notificationMessage, "chest_reward")
            }

            loadUserProfile()
        } catch (e: Exception) {
            _error.value = "Erro ao atualizar os pontos."
        }
        return pointsGained
    }

    fun requestWithdrawal(fullName: String, pixKey: String, amount: Double) {
        coroutineScope.launch {
            val user = auth.currentUser
            if (user == null) {
                _withdrawalMessage.value = "Usuário não logado."
                return@launch
            }

            if (userProfile.value?.blocked == true) {
                _withdrawalMessage.value = "Saques indisponíveis para esta conta."
                return@launch
            }

            if (!_appConfig.value.withdrawEnabled) {
                _withdrawalMessage.value = "Saques temporariamente indisponíveis."
                return@launch
            }
            
            if (amount < _appConfig.value.minWithdrawAmount) {
                _withdrawalMessage.value = "O valor mínimo para saque é R$ ${_appConfig.value.minWithdrawAmount}"
                return@launch
            }

            if (fullName.isBlank() || pixKey.isBlank() || amount <= 0) {
                _withdrawalMessage.value = "Preencha todos os campos."
                return@launch
            }

            _withdrawalMessage.value = "Processando..."

            try {
                firestore.runTransaction {
                    val userDocRef = firestore.collection("users").document(user.uid)
                    val userSnapshot = it.get(userDocRef)
                    val currentPoints = userSnapshot.getLong("points") ?: 0L

                    val pointsRequired = (amount * _appConfig.value.pointsPerReal).toLong()

                    if (currentPoints < pointsRequired) {
                        throw FirebaseFirestoreException(
                            "Pontos insuficientes para este saque.",
                            FirebaseFirestoreException.Code.ABORTED
                        )
                    }

                    val newPoints = currentPoints - pointsRequired

                    val requestDocRef = firestore.collection("withdrawRequests").document()
                    val request = mapOf(
                        "uid" to user.uid,
                        "email" to (user.email ?: ""),
                        "fullName" to fullName,
                        "pixKey" to pixKey,
                        "amountRequested" to amount,
                        "pointsRequired" to pointsRequired,
                        "status" to "pending",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "pointsRefunded" to false
                    )

                    val historyMessage = "Solicitação de saque de R$ ${"%.2f".format(amount)} enviada para análise"
                    val currentHistory = (userSnapshot.get("history") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    val newHistory = (listOf(historyMessage) + currentHistory).take(100)

                    it.set(requestDocRef, request)
                    it.update(userDocRef, "points", newPoints)
                    it.update(userDocRef, "history", newHistory)
                    it.update(userDocRef, "updatedAt", FieldValue.serverTimestamp())

                    null
                }.await()
                _withdrawalMessage.value = "Solicitação enviada com sucesso."

                createNotification(
                    uid = user.uid,
                    title = "Saque solicitado",
                    message = "Sua solicitação de saque foi enviada para análise.",
                    type = "withdrawal_requested"
                )

                loadUserProfile()
            } catch (e: Exception) {
                Log.e("FirestoreTransaction", "Transaction failed", e)
                val errorMessage = if (e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.ABORTED) {
                    e.message
                } else {
                    "Erro ao enviar solicitação. Tente novamente."
                }
                _withdrawalMessage.value = errorMessage
            }
        }
    }

    fun clearWithdrawalMessage() {
        _withdrawalMessage.value = null
    }

    fun loadWithdrawalRequests() {
        val user = auth.currentUser
        if (user == null) {
            _requestsError.value = "Usuário não logado."
            return
        }
        
        Log.d("Firestore", "Carregando solicitações do usuário")
        _isLoadingRequests.value = true
        _requestsError.value = null

        requestsListener?.remove()

        val query = firestore.collection("withdrawRequests").whereEqualTo("uid", user.uid)

        requestsListener = query.addSnapshotListener { snapshots, e ->
            if (e != null) {
                _isLoadingRequests.value = false
                _requestsError.value = "Erro ao carregar solicitações."
                Log.e("Firestore", "Erro ao carregar solicitações de saque", e)
                return@addSnapshotListener
            }

            if (snapshots != null) {
                Log.d("Firestore", "Solicitações carregadas com sucesso")
                val requests = snapshots.documents.mapNotNull { doc ->
                    doc.toObject(WithdrawalRequest::class.java)?.copy(id = doc.id)
                }
                .sortedByDescending { it.createdAt }
                
                _withdrawalRequests.value = requests.take(20)

                requests.forEach { request ->
                    checkAndCreateWithdrawalNotification(user.uid, request)
                }

                val requestsToRefund = requests.filter { 
                    it.status == "rejected" && it.pointsRefunded != true
                }

                if (requestsToRefund.isNotEmpty()) {
                    Log.d("Refund", "Solicitação rejeitada encontrada: ${requestsToRefund.size}")
                    coroutineScope.launch {
                        var profileNeedsRefresh = false
                        for (request in requestsToRefund) {
                            val success = refundRejectedWithdrawal(request.id)
                            if (success) profileNeedsRefresh = true
                        }
                        if (profileNeedsRefresh) {
                            Log.d("Refund", "Atualizando perfil do usuário após devoluções.")
                            loadUserProfile()
                        }
                    }
                }
            }
            _isLoadingRequests.value = false
        }
    }

    private fun checkAndCreateWithdrawalNotification(uid: String, request: WithdrawalRequest) {
        coroutineScope.launch {
            val status = request.status
            if (request.notificationSentForStatus[status] == true) return@launch

            val notificationType = when (status) {
                "approved" -> "withdrawal_approved"
                "rejected" -> "withdrawal_rejected"
                "paid" -> "withdrawal_paid"
                else -> return@launch
            }

            val title = when (status) {
                "approved" -> "Saque aprovado"
                "rejected" -> "Saque rejeitado"
                "paid" -> "Saque pago"
                else -> ""
            }
            val message = when (status) {
                "approved" -> "Sua solicitação de saque de R$ ${"%.2f".format(request.amountRequested)} foi aprovada."
                "rejected" -> "Sua solicitação de saque de R$ ${"%.2f".format(request.amountRequested)} foi rejeitada."
                "paid" -> "Seu saque de R$ ${"%.2f".format(request.amountRequested)} foi pago."
                else -> ""
            }

            createNotification(uid, title, message, notificationType)
            
            firestore.collection("withdrawRequests").document(request.id)
                .update("notificationSentForStatus.$status", true)
        }
    }

    private suspend fun refundRejectedWithdrawal(requestId: String): Boolean {
        val user = auth.currentUser ?: return false
        Log.d("Refund", "Iniciando devolução de pontos para a solicitação $requestId")

        try {
            val pointsRefunded = firestore.runTransaction { transaction ->
                val requestDocRef = firestore.collection("withdrawRequests").document(requestId)
                val userDocRef = firestore.collection("users").document(user.uid)

                val requestSnapshot = transaction.get(requestDocRef)

                if (!requestSnapshot.exists()) {
                    throw FirebaseFirestoreException("Solicitação não encontrada.", FirebaseFirestoreException.Code.NOT_FOUND)
                }

                val requestData = requestSnapshot.toObject(WithdrawalRequest::class.java)!!

                if (requestData.uid != user.uid) {
                    throw FirebaseFirestoreException("Permissão negada.", FirebaseFirestoreException.Code.PERMISSION_DENIED)
                }

                if (requestData.status != "rejected") {
                    Log.w("Refund", "Devolução ignorada: status não é 'rejected' para $requestId.")
                    return@runTransaction null
                }

                if (requestData.pointsRefunded == true) {
                    Log.i("Refund", "Devolução ignorada: pointsRefunded já é true para $requestId")
                    return@runTransaction null
                }

                val pointsToRefund = requestData.pointsRequired
                if (pointsToRefund <= 0) {
                    Log.w("Refund", "Devolução ignorada: valor de pontos a devolver é zero ou negativo para $requestId.")
                    transaction.update(requestDocRef, "pointsRefunded", true)
                    transaction.update(requestDocRef, "refundedAt", FieldValue.serverTimestamp())
                    return@runTransaction null
                }

                val userSnapshot = transaction.get(userDocRef)
                val currentPoints = userSnapshot.getLong("points") ?: 0L
                val newPoints = currentPoints + pointsToRefund

                val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
                val historyMessage = "Pontos devolvidos por saque rejeitado: +$pointsToRefund pontos - $timestamp"
                val currentHistory = (userSnapshot.get("history") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                val newHistory = (listOf(historyMessage) + currentHistory).take(100)

                Log.d("Refund", "Adicionando devolução ao histórico: '$historyMessage'")

                transaction.update(userDocRef, "points", newPoints)
                transaction.update(userDocRef, "history", newHistory)
                transaction.update(userDocRef, "updatedAt", FieldValue.serverTimestamp())

                transaction.update(requestDocRef, "pointsRefunded", true)
                transaction.update(requestDocRef, "refundedAt", FieldValue.serverTimestamp())

                pointsToRefund
            }.await()

            if (pointsRefunded != null) {
                createNotification(
                    uid = user.uid,
                    title = "Pontos devolvidos",
                    message = "Seu saque foi rejeitado e $pointsRefunded pontos foram devolvidos.",
                    type = "points_refunded"
                )
                Log.d("Refund", "Pontos devolvidos com sucesso para a solicitação $requestId")
                return true
            }
            return false
        } catch (e: Exception) {
            Log.e("RefundTx", "Erro ao devolver pontos para $requestId", e)
            return false
        }
    }

    private fun checkDailyBonus() {
        coroutineScope.launch {
            val user = auth.currentUser ?: return@launch
            val userProfile = _userProfile.value ?: return@launch

            val today = LocalDate.now()
            val todayStr = today.format(DateTimeFormatter.ISO_LOCAL_DATE) // yyyy-MM-dd

            val lastClaimDateStr = userProfile.dailyBonusLastClaimDate
            if (lastClaimDateStr == todayStr) {
                Log.d("DailyBonus", "Bônus já creditado hoje.")
                return@launch
            }

            val lastClaimDate = try {
                if (lastClaimDateStr.isNullOrEmpty()) null else LocalDate.parse(lastClaimDateStr)
            } catch (e: Exception) {
                null
            }

            val yesterday = today.minusDays(1)
            val currentStreak = userProfile.dailyBonusStreakDay ?: 0

            val nextStreakDay = when {
                lastClaimDate == yesterday -> if (currentStreak >= 7) 1 else currentStreak + 1
                else -> 1
            }

            val reward = when (nextStreakDay) {
                1 -> 5L
                2 -> 10L
                3 -> 30L
                4 -> 40L
                5 -> 130L
                6 -> 140L
                7 -> 300L
                else -> 0L
            }

            if (reward == 0L) return@launch

            val docRef = firestore.collection("users").document(user.uid)
            val historyMessage = "Bônus diário Dia $nextStreakDay: +$reward XP - ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}"

            try {
                firestore.runTransaction { transaction ->
                    val snapshot = transaction.get(docRef)
                    val currentXP = snapshot.getLong("xp") ?: 0L
                    val currentTotalBonus = snapshot.getLong("dailyBonusTotalEarned") ?: 0L
                    val currentHistory = (snapshot.get("history") as? List<*>)?.filterIsInstance<String>() ?: emptyList()

                    val newXP = currentXP + reward
                    val newTotalBonus = currentTotalBonus + reward
                    val newHistory = (listOf(historyMessage) + currentHistory).take(100)

                    transaction.update(docRef, mapOf(
                        "xp" to newXP,
                        "dailyBonusLastClaimDate" to todayStr,
                        "dailyBonusStreakDay" to nextStreakDay,
                        "dailyBonusTotalEarned" to newTotalBonus,
                        "history" to newHistory,
                        "updatedAt" to FieldValue.serverTimestamp()
                    ))
                }.await()

                val notificationTitle: String
                val notificationMessage: String
                if (nextStreakDay == 7) {
                    notificationTitle = "Grande prêmio recebido"
                    notificationMessage = "Você completou 7 dias seguidos e recebeu +300 XP!"
                } else {
                    notificationTitle = "Bônus diário recebido"
                    notificationMessage = "Você recebeu +$reward XP pelo Dia $nextStreakDay do bônus diário."
                }
                createNotification(user.uid, notificationTitle, notificationMessage, "daily_bonus")

                Log.d("DailyBonus", "Bônus de $reward XP creditado para o dia $nextStreakDay.")
                loadUserProfile()

            } catch (e: Exception) {
                Log.e("DailyBonus", "Erro ao creditar bônus diário", e)
            }
        }
    }


    fun createNotification(uid: String, title: String, message: String, type: String) {
        val notification = mapOf(
            "title" to title,
            "message" to message,
            "type" to type,
            "read" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        firestore.collection("users").document(uid).collection("notifications").add(notification)
    }

    fun loadNotifications() {
        val user = auth.currentUser
        if (user == null) {
            _notificationsError.value = "Usuário não logado."
            return
        }

        _isLoadingNotifications.value = true
        _notificationsError.value = null

        notificationsListener?.remove()

        notificationsListener = firestore.collection("users").document(user.uid).collection("notifications")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(30)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    _isLoadingNotifications.value = false
                    _notificationsError.value = "Erro ao carregar notificações."
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val notifications = snapshots.documents.mapNotNull { doc ->
                        doc.toObject(Notification::class.java)?.copy(id = doc.id)
                    }
                    _notifications.value = notifications
                }
                _isLoadingNotifications.value = false
            }
    }

    fun loadGlobalNotifications() {
        _isLoadingGlobalNotifications.value = true
        _globalNotificationsError.value = null

        globalNotificationsListener?.remove()

        globalNotificationsListener = firestore.collection("globalNotifications")
            .whereEqualTo("active", true)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    _isLoadingGlobalNotifications.value = false
                    _globalNotificationsError.value = "Erro ao carregar avisos globais"
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    val notifications = snapshots.documents.mapNotNull { doc ->
                        doc.toObject(GlobalNotification::class.java)?.copy(id = doc.id)
                    }
                    _globalNotifications.value = notifications
                }
                _isLoadingGlobalNotifications.value = false
            }
    }

    fun markNotificationsAsRead() {
        val user = auth.currentUser ?: return
        val notificationsToUpdate = _notifications.value.filter { !it.read }
        
        val batch = firestore.batch()
        notificationsToUpdate.forEach { notification ->
            val docRef = firestore.collection("users").document(user.uid).collection("notifications").document(notification.id)
            batch.update(docRef, "read", true)
        }
        batch.commit()
    }

    fun logout() {
        auth.signOut()
        requestsListener?.remove()
        notificationsListener?.remove()
        globalNotificationsListener?.remove()
        _userProfile.value = null
        _withdrawalRequests.value = emptyList()
        _notifications.value = emptyList()
        _isLoading.value = false
        _error.value = null
    }
}
