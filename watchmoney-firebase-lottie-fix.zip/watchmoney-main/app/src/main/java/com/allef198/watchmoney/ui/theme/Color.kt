package com.allef198.watchmoney.ui.theme

import androidx.compose.ui.graphics.Color

val DarkGreen = Color(0xFF0B5D3B)
val MediumGreen = Color(0xFF127C4F)
val LightGreen = Color(0xFFDFF5EA)
val Background = Color(0xFFF6F7F9)
val CardBackground = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF172321)
val TextSecondary = Color(0xFF6B7280)
val RedError = Color(0xFFD32F2F)
val YellowAlert = Color(0xFFF9A825)
