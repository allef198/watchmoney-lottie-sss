package com.allef198.watchmoney

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.airbnb.lottie.compose.*
import com.allef198.watchmoney.composables.HistoryItem
import com.allef198.watchmoney.composables.PrimaryActionButton
import com.allef198.watchmoney.composables.ScreenContainer
import com.allef198.watchmoney.composables.SecondaryActionButton
import com.allef198.watchmoney.composables.SectionTitle
import com.allef198.watchmoney.ui.theme.WatchMoneyTheme
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : ComponentActivity() {
    private val userRepository = UserRepository()
    private lateinit var rewardedAdManager: RewardedAdManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        MobileAds.initialize(this) {}

        rewardedAdManager = RewardedAdManager(this, userRepository)
        rewardedAdManager.loadAd()

        setContent {
            WatchMoneyTheme {
                WatchMoneyApp(userRepository, rewardedAdManager)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        userRepository.onCleared()
    }
}

val GreenMain = Color(0xFF0F6B3E)
val GreenDark = Color(0xFF064E2B)
val BackgroundLight = Color(0xFFF7F8FA)
val TextMain = Color(0xFF111827)
val TextSecondary = Color(0xFF6B7280)
val CardLight = Color(0xFFFFFFFF)
val HighlightSoft = Color(0xFFEAF7EF)

sealed class AppScreen(val title: String, val icon: ImageVector) {
    object Home : AppScreen("Início", Icons.Default.Home)
    object Wallet : AppScreen("Carteira", Icons.Default.AccountBalanceWallet)
    object History : AppScreen("Histórico", Icons.Default.History)
    object Missions : AppScreen("Missões", Icons.Default.Checklist)
    object Notifications : AppScreen("Notificações", Icons.Default.History)
    object DailyBonus : AppScreen("Bônus Diário", Icons.Default.History)
}

enum class RewardVisualType {
    NONE,
    NORMAL_REWARD,
    SUPER_CHEST_READY,
    SUPER_CHEST_OPENING,
    SUPER_CHEST_LEVEL_UP
}

class RewardedAdManager(private val context: Context, private val userRepository: UserRepository) {
    private var rewardedAd: RewardedAd? = null
    private var isLoading = false

    private val _adState = MutableStateFlow<AdState>(AdState.NotReady)
    val adState: StateFlow<AdState> = _adState

    fun loadAd() {
        if (isLoading) return
        isLoading = true
        _adState.value = AdState.Loading

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(context, AdMobConfig.REWARDED_AD_UNIT_ID, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                Log.d("AdMob", adError.message)
                rewardedAd = null
                isLoading = false
                _adState.value = AdState.Error("Anúncio indisponível. Tente novamente.")
            }

            override fun onAdLoaded(ad: RewardedAd) {
                Log.d("AdMob", "Ad was loaded.")
                rewardedAd = ad
                isLoading = false
                _adState.value = AdState.Ready
            }
        })
    }

    fun showAd(activity: Activity, onAdWatched: () -> Unit, onAdRewarded: (Long) -> Unit) {
        if (rewardedAd != null) {
            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    loadAd()
                }
            }
            rewardedAd?.show(activity) { 
                CoroutineScope(Dispatchers.Main).launch {
                    onAdWatched()
                    val pointsGained = userRepository.onAdWatched()
                    onAdRewarded(pointsGained)
                }
            }
        } else {
            loadAd()
        }
    }
}

sealed class AdState {
    object NotReady : AdState()
    object Loading : AdState()
    object Ready : AdState()
    data class Error(val message: String) : AdState()
}

@Composable
private fun WatchMoneyApp(userRepository: UserRepository, rewardedAdManager: RewardedAdManager) {
    val userProfile by userRepository.userProfile.collectAsState()
    val isLoading by userRepository.isLoading.collectAsState()
    val error by userRepository.error.collectAsState()
    val appConfig by userRepository.appConfig.collectAsState()

    var authState by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }

    DisposableEffect(Unit) {
        val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            authState = firebaseAuth.currentUser
        }
        FirebaseAuth.getInstance().addAuthStateListener(authStateListener)
        onDispose {
            FirebaseAuth.getInstance().removeAuthStateListener(authStateListener)
        }
    }

    LaunchedEffect(authState) {
        if (authState != null) {
            userRepository.loadUserProfile()
            userRepository.loadWithdrawalRequests()
            userRepository.loadNotifications()
        } else {
            userRepository.logout()
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = BackgroundLight,
    ) {
        when {
            isLoading && userProfile == null -> {
                ScreenContainer {
                    CircularProgressIndicator(color = GreenMain)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Carregando seus dados...", color = TextMain)
                }
            }
            error != null -> {
                ErrorScreen(
                    error = error!!,
                    onRetry = { userRepository.loadUserProfile() },
                    onLogout = { userRepository.logout() }
                )
            }
            authState == null -> {
                var showLogin by remember { mutableStateOf(true) }
                if (showLogin) {
                    LoginScreen(
                        onLoginSuccess = { },
                        onNavigateToSignUp = { showLogin = false }
                    )
                } else {
                    SignUpScreen(
                        onSignUpSuccess = { },
                        onNavigateToLogin = { showLogin = true }
                    )
                }
            }
            userProfile != null -> {
                var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Home) }
                MainAppScaffold(
                    userRepository = userRepository,
                    rewardedAdManager = rewardedAdManager,
                    userProfile = userProfile!!,
                    appConfig = appConfig,
                    currentScreen = currentScreen,
                    onScreenSelected = { currentScreen = it },
                    onLogout = { userRepository.logout() },
                )
            }
             else -> {
                ScreenContainer {
                    CircularProgressIndicator(color = GreenMain)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Verificando usuário...", color = TextMain)
                }
            }
        }
    }
}


@Composable
private fun ErrorScreen(error: String, onRetry: () -> Unit, onLogout: () -> Unit) {
    ScreenContainer {
        Text(error, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(16.dp))
        PrimaryActionButton("Tentar Novamente", onClick = onRetry)
        Spacer(modifier = Modifier.height(12.dp))
        SecondaryActionButton("Sair", onClick = onLogout)
    }
}


@Composable
private fun MainAppScaffold(
    userRepository: UserRepository,
    rewardedAdManager: RewardedAdManager,
    userProfile: UserProfile,
    appConfig: AppConfig,
    currentScreen: AppScreen,
    onScreenSelected: (AppScreen) -> Unit,
    onLogout: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val haptic = LocalHapticFeedback.current

    var rewardVisualState by remember { mutableStateOf(RewardVisualType.NONE) }
    var playChestProgressAnimation by remember { mutableStateOf(0L) }

    Scaffold(
        bottomBar = {
            if (currentScreen != AppScreen.DailyBonus) {
                 AppBottomNavigation(
                    currentScreen = currentScreen,
                    onScreenSelected = onScreenSelected,
                )
            }
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize()) {
            Crossfade(targetState = currentScreen, animationSpec = tween(300), label = "screen_crossfade") { screen ->
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    color = Color.Transparent,
                ) {
                    when (screen) {
                        AppScreen.Home -> HomeScreen(
                            userProfile = userProfile,
                            adState = rewardedAdManager.adState.collectAsState().value,
                            onShowAd = {
                                activity?.let {
                                    rewardedAdManager.showAd(
                                        activity = it,
                                        onAdWatched = { playChestProgressAnimation = System.currentTimeMillis() },
                                        onAdRewarded = { pointsGained ->
                                            if (pointsGained > 0) {
                                                if (pointsGained >= 100) { // Super Baú
                                                    rewardVisualState = RewardVisualType.SUPER_CHEST_READY
                                                } else { // Recompensa normal
                                                    rewardVisualState = RewardVisualType.NORMAL_REWARD
                                                }
                                            }
                                        }
                                    )
                                }
                            },
                            appConfig = appConfig,
                            onNavigateToDailyBonus = { onScreenSelected(AppScreen.DailyBonus) },
                            onNavigateToWallet = { onScreenSelected(AppScreen.Wallet) },
                            playChestProgressAnimation = playChestProgressAnimation
                        )
                        AppScreen.Wallet -> WalletScreen(
                            userRepository = userRepository,
                            userProfile = userProfile,
                            appConfig = appConfig,
                            onNavigateToTerms = {
                                val intent = Intent(context, WithdrawalTermsActivity::class.java)
                                context.startActivity(intent)
                            },
                            onLogout = onLogout,
                            onNavigateToNotifications = { onScreenSelected(AppScreen.Notifications) }
                        )
                        AppScreen.History -> HistoryScreen(history = userProfile.history)
                        AppScreen.Missions -> MissionsScreen()
                        AppScreen.Notifications -> NotificationsScreen(userRepository = userRepository)
                        AppScreen.DailyBonus -> DailyBonusScreen(
                            userProfile = userProfile,
                            onBack = { onScreenSelected(AppScreen.Home) }
                        )
                    }
                }
            }

            RewardOverlay(
                rewardState = rewardVisualState,
                onStateChange = { rewardVisualState = it },
                onSuperChestOpen = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    rewardVisualState = RewardVisualType.SUPER_CHEST_OPENING
                }
            )
        }
    }
}

@Composable
fun AppBottomNavigation(
    currentScreen: AppScreen,
    onScreenSelected: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = CardLight,
        tonalElevation = 8.dp
    ) {
        val items = listOf(AppScreen.Home, AppScreen.Missions, AppScreen.History)
        items.forEach { screen ->
            NavigationBarItem(
                icon = { Icon(screen.icon, contentDescription = screen.title) },
                label = { Text(screen.title) },
                selected = currentScreen == screen,
                onClick = { onScreenSelected(screen) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = GreenMain,
                    selectedTextColor = GreenMain,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = HighlightSoft
                )
            )
        }
    }
}

@Composable
private fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onNavigateToSignUp: () -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenContainer {
        Text("Entrar", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = password,
            onValueChange = { password = it },
            label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        Spacer(modifier = Modifier.height(24.dp))
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            PrimaryActionButton(text = "Entrar", onClick = {
                if (email.isNotBlank() && password.isNotBlank()) {
                    isLoading = true
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            isLoading = false
                            if (task.isSuccessful) {
                                onLoginSuccess()
                            } else {
                                error = task.exception?.message ?: "Ocorreu um erro"
                            }
                        }
                }
            })
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        TextButton(onClick = onNavigateToSignUp) {
            Text("Criar conta")
        }
    }
}

@Composable
private fun SignUpScreen(
    onSignUpSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenContainer {
        Text("Criar Conta", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = password,
            onValueChange = { password = it },
            label = { Text("Senha") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirmar Senha") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        Spacer(modifier = Modifier.height(24.dp))
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            PrimaryActionButton(text = "Cadastrar", onClick = {
                if (email.isNotBlank() && password.isNotBlank() && confirmPassword.isNotBlank()) {
                    if (password == confirmPassword) {
                        isLoading = true
                        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                isLoading = false
                                if (task.isSuccessful) {
                                    onSignUpSuccess()
                                } else {
                                    error = task.exception?.message ?: "Ocorreu um erro"
                                }
                            }
                    } else {
                        error = "As senhas não coincidem"
                    }
                }
            })
        }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        TextButton(onClick = onNavigateToLogin) {
            Text("Já tenho conta")
        }
    }
}

@Composable
private fun HomeScreen(
    userProfile: UserProfile,
    adState: AdState,
    onShowAd: () -> Unit,
    appConfig: AppConfig,
    onNavigateToDailyBonus: () -> Unit,
    onNavigateToWallet: () -> Unit,
    playChestProgressAnimation: Long
) {
    var adErrorMessage by remember { mutableStateOf<String?>(null) }
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        isVisible = true
    }

    LaunchedEffect(adState) {
        if (adState is AdState.Error) {
            adErrorMessage = adState.message
            delay(3000)
            adErrorMessage = null
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = slideInVertically(initialOffsetY = { it / 2 }, animationSpec = tween(durationMillis = 500)) + 
                      fadeIn(animationSpec = tween(durationMillis = 400)),
            ) {
                BalanceCard(points = userProfile.points, onNavigateToWallet = onNavigateToWallet)
            }
        }

        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(animationSpec = tween(durationMillis = 500, delayMillis = 200)),
            ) {
                WatchAdButton(adState = adState, onShowAd = onShowAd, adErrorMessage = adErrorMessage)
            }
        }
        
        item {
            AnimatedVisibility(
                visible = isVisible,
                 enter = fadeIn(animationSpec = tween(durationMillis = 500, delayMillis = 300)),
            ) {
                ChestProgressBar(userProfile = userProfile, playChestProgressAnimation = playChestProgressAnimation)
            }
        }
        
        item {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(animationSpec = tween(durationMillis = 500, delayMillis = 400)),
            ) {
                DailyBonusHomeCard(userProfile = userProfile, onNavigateToDailyBonus = onNavigateToDailyBonus)
            }
        }
    }
}

@Composable
fun WatchAdButton(
    adState: AdState,
    onShowAd: () -> Unit,
    adErrorMessage: String?
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(targetValue = if (isPressed) 0.97f else 1f, label = "button_scale")

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Button(
            onClick = onShowAd,
            enabled = adState == AdState.Ready,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 64.dp)
                .scale(scale),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GreenMain),
            interactionSource = interactionSource
        ) {
            AnimatedContent(targetState = adState, label = "button_content") { state ->
                when (state) {
                    is AdState.Loading -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(28.dp)) {
                                CircularProgressIndicator(modifier = Modifier.padding(4.dp), color = Color.White, strokeWidth = 2.dp)
                            }
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Text("Carregando anúncio...", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Filled.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Assistir anúncio", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text(text = "e ganhar pontos", fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }

        adErrorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun BalanceCard(
    points: Long,
    onNavigateToWallet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val gradientBrush = Brush.verticalGradient(
        colors = listOf(GreenMain, GreenDark)
    )

    val animatedPoints by animateFloatAsState(
        targetValue = points.toFloat(),
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "points_counter"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(230.dp)
            .shadow(elevation = 8.dp, shape = RoundedCornerShape(28.dp))
            .clip(RoundedCornerShape(28.dp))
            .background(gradientBrush)
            .padding(24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(
                    text = "Saldo disponível",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 17.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = NumberFormat.getNumberInstance(Locale.getDefault()).format(animatedPoints.toLong()),
                    color = Color.White,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "pontos acumulados",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 17.sp
                )
            }
            
            OutlinedButton(
                onClick = onNavigateToWallet,
                modifier = Modifier
                    .align(Alignment.End)
                    .defaultMinSize(minHeight = 44.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.White
                ),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
            ) {
                Text("Ver carteira", fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun ChestProgressBar(
    userProfile: UserProfile,
    playChestProgressAnimation: Long,
    modifier: Modifier = Modifier
) {
    val chestProgress = userProfile.chestProgress
    val animatedProgress by animateFloatAsState(
        targetValue = chestProgress.toFloat() / 20f, 
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "chest_progress"
    )

    val nextRewardProgress = when {
        chestProgress < 5 -> 5
        chestProgress < 10 -> 10
        chestProgress < 15 -> 15
        else -> 20
    }
    val pointsForNextReward = when (nextRewardProgress) {
        5 -> 25
        10 -> 25
        15 -> 50
        else -> 100
    }
    val adsRemaining = nextRewardProgress - chestProgress

    val nextRewardText = when {
        adsRemaining > 0 -> "Faltam $adsRemaining anúncios para liberar a recompensa."
        else -> "Você abriu o baú!"
    }
    
    val isChestReady = chestProgress >= 20
    val infiniteTransition = rememberInfiniteTransition(label = "chest_glow")
    val glow by infiniteTransition.animateFloat(
        initialValue = if(isChestReady) 1f else 0f,
        targetValue = if(isChestReady) 1.05f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = ""
    )

    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.chest_progress))
    val progress by animateLottieCompositionAsState(
        composition,
        isPlaying = playChestProgressAnimation > 0,
        restartOnPlay = true,
        iterations = 1
    )

    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .scale(if (isChestReady) glow else 1f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = CardLight),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "🎁 Baú de recompensas",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = "Complete 20 anúncios e abra o baú especial.",
                    fontSize = 17.sp,
                    color = TextSecondary
                )
                
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                    color = GreenMain,
                    trackColor = HighlightSoft
                )
                
                Column {
                    Text(
                        text = "$chestProgress/20 anúncios",
                        fontSize = 16.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Próxima recompensa: +$pointsForNextReward pts",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = GreenMain
                    )
                }
                
                Text(
                    text = nextRewardText,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        if (progress < 1.0f && progress > 0f) {
            LottieAnimation(
                composition = composition,
                progress = { progress },
                modifier = Modifier.size(150.dp).offset(y = (-30).dp)
            )
        }
    }
}

@Composable
private fun DailyBonusHomeCard(userProfile: UserProfile, onNavigateToDailyBonus: () -> Unit) {
    val currentStreak = userProfile.dailyBonusStreakDay ?: 0
    val lastClaimDateStr = userProfile.dailyBonusLastClaimDate ?: ""

    val today = LocalDate.now()
    val todayStr = today.format(DateTimeFormatter.ISO_LOCAL_DATE)
    val hasClaimedToday = lastClaimDateStr == todayStr
    val lastClaimDate = try { LocalDate.parse(lastClaimDateStr) } catch (e: Exception) { null }

    val displayDay = when {
        hasClaimedToday -> currentStreak
        lastClaimDate == today.minusDays(1) -> if (currentStreak >= 7) 1 else currentStreak + 1
        else -> 1
    }.coerceIn(1, 7)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigateToDailyBonus() },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = HighlightSoft)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Bônus diário",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMain
                )
                Text(
                    text = "Dia $displayDay de 7",
                    fontSize = 17.sp,
                    color = TextSecondary
                )
            }
            Text(
                text = "Ver progresso",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = GreenMain
            )
        }
    }
}

@Composable
private fun MissionsScreen() {
    ScreenContainer {
        Text("Missões", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Novas missões em breve.", fontSize = 18.sp, color = TextSecondary)
    }
}


@Composable
private fun DailyBonusScreen(userProfile: UserProfile, onBack: () -> Unit) {
    val rewards = listOf(5L, 10L, 30L, 40L, 130L, 140L, 300L)
    val currentStreak = userProfile.dailyBonusStreakDay ?: 0
    val lastClaimDateStr = userProfile.dailyBonusLastClaimDate ?: ""

    val today = LocalDate.now()
    val todayStr = today.format(DateTimeFormatter.ISO_LOCAL_DATE)
    val hasClaimedToday = lastClaimDateStr == todayStr
    val lastClaimDate = try { LocalDate.parse(lastClaimDateStr) } catch (e: Exception) { null }
    val nextRewardDay = if (currentStreak >= 7) 1 else currentStreak + 1

    val displayDay = when {
        hasClaimedToday -> currentStreak
        lastClaimDate == today.minusDays(1) -> nextRewardDay
        else -> 1
    }.coerceIn(1, 7)

    val statusMessage = if (hasClaimedToday) {
        "Você já recebeu o bônus de hoje."
    } else {
        "Entre hoje para receber seu bônus diário."
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Bônus diário", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Entre todos os dias para aumentar sua sequência.", textAlign = TextAlign.Center)
        }
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text("Status: Dia $displayDay de 7", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(statusMessage, fontSize = 16.sp, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(16.dp))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                rewards.indices.forEach { index ->
                    val day = index + 1
                    DailyBonusProgressDot(
                        day = day,
                        isCompleted = day <= currentStreak,
                        isCurrent = day == displayDay && !hasClaimedToday
                    )
                }
            }
        }

        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Recompensas:", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                rewards.forEachIndexed { index, reward ->
                    val day = index + 1
                    Text("Dia $day: +$reward XP", color = if(day == displayDay) MaterialTheme.colorScheme.primary else Color.Unspecified)
                }
            }
        }

        item {
            Text(
                text = "Se ficar um dia sem entrar, sua sequência volta para o Dia 1.",
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Text(
                    text = "Grande prêmio no Dia 7: +300 XP",
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
            SecondaryActionButton("Voltar", onClick = onBack)
        }
    }
}


@Composable
private fun DailyBonusProgressDot(
    day: Int,
    isCompleted: Boolean,
    isCurrent: Boolean
) {
    val backgroundColor = when {
        isCurrent -> MaterialTheme.colorScheme.primary
        isCompleted -> MaterialTheme.colorScheme.secondaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    val contentColor = when {
        isCurrent -> MaterialTheme.colorScheme.onPrimary
        isCompleted -> MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .size(32.dp)
            .clip(CircleShape)
            .background(backgroundColor),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = day.toString(),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = contentColor
        )
    }
}



@Composable
private fun WalletScreen(
    userRepository: UserRepository,
    userProfile: UserProfile,
    appConfig: AppConfig,
    onNavigateToTerms: () -> Unit,
    onLogout: () -> Unit,
    onNavigateToNotifications: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var pixKey by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val withdrawalMessage by userRepository.withdrawalMessage.collectAsState()

    val requests by userRepository.withdrawalRequests.collectAsState()
    val isLoadingRequests by userRepository.isLoadingRequests.collectAsState()
    val requestsError by userRepository.requestsError.collectAsState()
    val numberFormat = NumberFormat.getNumberInstance(Locale("pt", "BR")).apply {
        maximumFractionDigits = 0
    }

    val pointsPerRealText = "${numberFormat.format(appConfig.pointsPerReal)} pontos = R$ 1,00"

    LaunchedEffect(withdrawalMessage) {
        if (withdrawalMessage != null) {
            delay(4000) 
            userRepository.clearWithdrawalMessage()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            SectionTitle("Seu Saldo")
            // BalanceCard is now on the home screen
            Spacer(modifier = Modifier.height(8.dp))
            Text(pointsPerRealText, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(32.dp))

            if (userProfile.blocked) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text(
                        text = "Sua conta está em análise. Entre em contato com o suporte.",
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                 PrimaryActionButton("Saques indisponíveis para esta conta.", enabled = false, onClick = {})

            } else {
                SectionTitle("Solicitar saque")
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Nome completo") },
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = pixKey,
                    onValueChange = { pixKey = it },
                    label = { Text("Chave Pix") },
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth(),
                    value = amount,
                    onValueChange = { amount = it.filter { c -> c.isDigit() || c == ',' || c == '.' } },
                    label = { Text("Valor do saque (R$ ${appConfig.minWithdrawAmount})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Os pontos são reservados quando você solicita o saque.",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(24.dp))

                if (appConfig.withdrawEnabled){
                    PrimaryActionButton("Solicitar saque") {
                        val amountValue = amount.replace(',', '.').toDoubleOrNull() ?: 0.0
                        userRepository.requestWithdrawal(fullName, pixKey, amountValue)
                    }
                } else {
                    PrimaryActionButton("Saques temporariamente indisponíveis.", enabled = false, onClick = {})
                }


                withdrawalMessage?.let {
                    Spacer(modifier = Modifier.height(16.dp))
                    val isError = it.startsWith("Erro") || it.startsWith("Pontos") || it.startsWith("Preencha") || it.startsWith("O valor") || it.startsWith("Saques")
                    Text(
                        it,
                        color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(32.dp))

            SectionTitle("Minhas solicitações")
        }

        when {
            isLoadingRequests -> {
                item { CircularProgressIndicator() }
            }
            requestsError != null -> {
                item { Text(requestsError!!, color = MaterialTheme.colorScheme.error) }
            }
            requests.isEmpty() -> {
                item { Text("Nenhuma solicitação de saque ainda.") }
            }
            else -> {
                items(requests) { request ->
                    WithdrawalRequestItem(request)
                    Spacer(modifier = Modifier.height(12.dp))
                }
                if (requests.size >= 20) {
                    item {
                        Text(
                            "Mostrando as solicitações mais recentes.",
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
            SectionTitle("Perfil")
            val context = LocalContext.current
            AccountInfo(userProfile, onNavigateToTerms, onLogout, onNavigateToNotifications, onNavigateToHowItWorks = {
                val intent = Intent(context, HowItWorksActivity::class.java)
                context.startActivity(intent)
            })
        }
    }
}

@Composable
private fun NotificationsScreen(userRepository: UserRepository) {
    val notifications by userRepository.notifications.collectAsState()
    val isLoading by userRepository.isLoadingNotifications.collectAsState()
    val error by userRepository.notificationsError.collectAsState()

    val globalNotifications by userRepository.globalNotifications.collectAsState()
    val isLoadingGlobal by userRepository.isLoadingGlobalNotifications.collectAsState()
    val errorGlobal by userRepository.globalNotificationsError.collectAsState()

    LaunchedEffect(Unit) {
        userRepository.markNotificationsAsRead()
    }

    ScreenContainer {
        Text("Avisos", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Acompanhe atualizações importantes da sua conta", fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(24.dp))

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
                Text("Avisos gerais", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
            }
            when {
                isLoadingGlobal -> item { CircularProgressIndicator() }
                errorGlobal != null -> item { Text(errorGlobal!!, color = MaterialTheme.colorScheme.error) }
                globalNotifications.isEmpty() -> item { Text("Nenhum aviso geral no momento.") }
                else -> {
                    items(globalNotifications) { notification ->
                        GlobalNotificationItem(notification)
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text("Seus avisos", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
            }
            when {
                isLoading -> item { CircularProgressIndicator() }
                error != null -> item { Text(error!!, color = MaterialTheme.colorScheme.error) }
                notifications.isEmpty() -> item { Text("Nenhum aviso ainda.") }
                else -> {
                    items(notifications) { notification ->
                        NotificationItem(notification)
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlobalNotificationItem(notification: GlobalNotification) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(notification.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(notification.message, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = formatDate(notification.createdAt),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun NotificationItem(notification: Notification) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!notification.read) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                )
                Spacer(modifier = Modifier.width(16.dp))
            }
            Column {
                Text(notification.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(notification.message, fontSize = 14.sp)
                Text(
                    text = formatDate(notification.createdAt),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun AccountInfo(
    userProfile: UserProfile,
    onNavigateToTerms: () -> Unit,
    onLogout: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToHowItWorks: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Conta conectada", fontWeight = FontWeight.Bold)
        Text(userProfile.email)
        Spacer(modifier = Modifier.height(16.dp))
        SecondaryActionButton("Avisos", onClick = onNavigateToNotifications)
        Spacer(modifier = Modifier.height(12.dp))
        SecondaryActionButton("Como funciona", onClick = onNavigateToHowItWorks)
        Spacer(modifier = Modifier.height(12.dp))
        SecondaryActionButton("Termos e saque", onClick = onNavigateToTerms)
        Spacer(modifier = Modifier.height(12.dp))
        SecondaryActionButton("Sair", onClick = onLogout)
    }
}

fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) return context
        context = context.baseContext
    }
    return null
}

private fun translateStatus(status: String): String {
    return when (status.lowercase()) {
        "pending" -> "Em análise"
        "approved" -> "Aprovado"
        "rejected" -> "Rejeitado"
        "paid" -> "Pago"
        else -> status
    }
}

private fun formatDate(timestamp: Timestamp?): String {
    if (timestamp == null) return "Data indisponível"
    val sdf = java.text.SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", Locale.getDefault())
    return sdf.format(timestamp.toDate())
}


@Composable
private fun WithdrawalRequestItem(request: WithdrawalRequest) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "R$ ${"%.2f".format(request.amountRequested)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = translateStatus(request.status),
                    fontWeight = FontWeight.Medium,
                    color = when (request.status) {
                        "pending" -> Color.Blue
                        "approved" -> MaterialTheme.colorScheme.primary
                        "paid" -> MaterialTheme.colorScheme.primary
                        "rejected" -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${request.pointsRequired} pontos",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = formatDate(request.createdAt),
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
             if (request.status == "rejected" && request.pointsRefunded == true) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Pontos devolvidos",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}


@Composable
private fun HistoryScreen(history: List<String>) {
    ScreenContainer(horizontalAlignment = Alignment.Start) {
        Text(
            text = "Histórico",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(modifier = Modifier.height(20.dp))
        if (history.isEmpty()) {
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = "Nenhuma atividade ainda.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
            )
        } else {
            val recentHistory = history.take(50)
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(recentHistory) { item ->
                    HistoryItem(text = item)
                }
                if (history.size > 50) {
                    item {
                        Text(
                            "Mostrando os registros mais recentes.",
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RewardOverlay(
    rewardState: RewardVisualType,
    onStateChange: (RewardVisualType) -> Unit,
    onSuperChestOpen: () -> Unit
) {
    val transition = updateTransition(targetState = rewardState, label = "OverlayTransition")

    transition.AnimatedVisibility(
        visible = { it != RewardVisualType.NONE },
        enter = fadeIn(animationSpec = tween(300)),
        exit = fadeOut(animationSpec = tween(300))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .zIndex(100f)
                .clickable(enabled = false) {},
            contentAlignment = Alignment.Center
        ) {
            when (rewardState) {
                RewardVisualType.NORMAL_REWARD -> {
                    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.coin_reward))
                    val progress by animateLottieCompositionAsState(composition, iterations = 1)

                    LottieAnimation(
                        composition = composition,
                        progress = { progress },
                        modifier = Modifier.size(250.dp)
                    )

                    if (progress == 1.0f) {
                        LaunchedEffect(Unit) { onStateChange(RewardVisualType.NONE) }
                    }
                }

                RewardVisualType.SUPER_CHEST_READY -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Super Baú Liberado!", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = onSuperChestOpen,
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GreenMain),
                            modifier = Modifier.defaultMinSize(minHeight = 64.dp, minWidth = 250.dp)
                        ) {
                            Text("Abrir Super Baú", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                RewardVisualType.SUPER_CHEST_OPENING -> {
                    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.super_chest))
                    val progress by animateLottieCompositionAsState(composition, iterations = 1)

                    LottieAnimation(
                        composition = composition,
                        progress = { progress },
                        modifier = Modifier.size(400.dp)
                    )

                    if (progress == 1.0f) {
                        LaunchedEffect(Unit) { onStateChange(RewardVisualType.SUPER_CHEST_LEVEL_UP) }
                    }
                }

                RewardVisualType.SUPER_CHEST_LEVEL_UP -> {
                    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.level_up_reward))
                    val progress by animateLottieCompositionAsState(composition, iterations = 1)

                    LottieAnimation(
                        composition = composition,
                        progress = { progress },
                        modifier = Modifier.size(400.dp)
                    )

                    if (progress == 1.0f) {
                        LaunchedEffect(Unit) {
                            delay(500) // Pequeno delay para o usuário ver o final da animação
                            onStateChange(RewardVisualType.NONE)
                        }
                    }
                }

                RewardVisualType.NONE -> { /* Não mostra nada */ }
            }
        }
    }
}
