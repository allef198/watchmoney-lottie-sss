package com.allef198.watchmoney

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.allef198.watchmoney.composables.InfoCard
import com.allef198.watchmoney.ui.theme.WatchMoneyTheme

class WithdrawalTermsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WatchMoneyTheme {
                WithdrawalTermsScreen()
            }
        }
    }
}

@Composable
fun WithdrawalTermsScreen() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        LazyColumn(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    "Termos e Política de Saque",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            item {
                InfoCard(
                    title = "Pontos",
                    description = "Os pontos são acumulados ao assistir anúncios disponíveis no app. Os pontos ficam salvos na conta do usuário."
                )
            }

            item {
                InfoCard(
                    title = "Conversão",
                    description = "A conversão atual é: 10.000 pontos = R$ 1,00."
                )
            }

            item {
                InfoCard(
                    title = "Solicitação de saque",
                    description = "Para solicitar saque, o usuário deve informar nome completo, chave Pix e valor desejado."
                )
            }

            item {
                InfoCard(
                    title = "Análise manual",
                    description = "Todas as solicitações de saque passam por análise manual antes do pagamento."
                )
            }

            item {
                InfoCard(
                    title = "Pontos reservados",
                    description = "Ao solicitar um saque, os pontos necessários ficam reservados até a análise."
                )
            }

            item {
                InfoCard(
                    title = "Saque aprovado",
                    description = "Se o saque for aprovado, ele poderá ser marcado como pago após o envio do Pix."
                )
            }

            item {
                InfoCard(
                    title = "Saque rejeitado",
                    description = "Se o saque for rejeitado, os pontos reservados serão devolvidos automaticamente."
                )
            }
            
            item {
                InfoCard(
                    title = "Uso correto",
                    description = "Atividades suspeitas, uso indevido, tentativa de manipular pontos ou uso de múltiplas contas podem causar rejeição de saques."
                )
            }

            item {
                InfoCard(
                    title = "Alterações",
                    description = "As regras, valores e conversão de pontos podem ser ajustados em versões futuras do app."
                )
            }
        }
    }
}
