package com.allef198.watchmoney

object AdMobConfig {
    const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
}