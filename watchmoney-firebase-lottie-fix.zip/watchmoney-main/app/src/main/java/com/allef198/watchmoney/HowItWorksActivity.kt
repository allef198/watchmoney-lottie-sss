package com.allef198.watchmoney

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.allef198.watchmoney.ui.theme.WatchMoneyTheme

class HowItWorksActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WatchMoneyTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    HowItWorksScreen()
                }
            }
        }
    }
}

@Composable
fun HowItWorksScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 32.dp)
    ) {
        item {
            Text(
                text = "Como funciona",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(32.dp))
        }

        item {
            HowItWorksCard(
                title = "Como ganhar pontos",
                description = "Você ganha pontos ao assistir anúncios recompensados. Os pontos são creditados em sua conta assim que o anúncio termina e a recompensa é validada."
            )
        }

        item {
            HowItWorksCard(
                title = "Como funciona o saque",
                description = "Para solicitar um saque, você precisa ter a quantidade mínima de pontos. Atualmente, 10.000 pontos equivalem a R$ 1,00. Todos os saques são processados manualmente e podem levar alguns dias."
            )
        }

        item {
            HowItWorksCard(
                title = "Pontos reservados",
                description = "Quando você solicita um saque, os pontos correspondentes são reservados e deduzidos do seu saldo. Eles não podem ser usados para outros saques enquanto a solicitação estiver em análise."
            )
        }

        item {
            HowItWorksCard(
                title = "Análise manual",
                description = "Todas as solicitações de saque passam por uma análise manual para garantir que não houve nenhuma atividade suspeita ou violação de nossos termos. Isso ajuda a manter a plataforma segura para todos."
            )
        }

        item {
            HowItWorksCard(
                title = "Saque rejeitado",
                description = "Se uma solicitação de saque for rejeitada, os pontos que foram reservados serão devolvidos integralmente à sua conta. Você verá um registro no seu histórico sobre a devolução."
            )
        }

        item {
            HowItWorksCard(
                title = "Uso correto",
                description = "Para garantir que seus saques sejam aprovados, utilize o aplicativo de forma justa. Evite o uso de qualquer ferramenta para automatizar a visualização de anúncios ou qualquer outra atividade que viole nossos termos de serviço."
            )
        }
    }
}

@Composable
fun HowItWorksCard(title: String, description: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = description,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
